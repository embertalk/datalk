<?php

/** @generate-function-entries */

function apache_child_terminate(): void {}

function apache_request_headers(): array {}

/** @alias apache_request_headers */
function getallheaders(): array {}

function apache_response_headers(): array {}
