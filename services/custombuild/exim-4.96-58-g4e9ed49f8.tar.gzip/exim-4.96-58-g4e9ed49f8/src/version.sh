# automatically generated file - see ../scripts/reversion
EXIM_RELEASE_VERSION="4.96"
EXIM_VARIANT_VERSION="58-g4e9ed49f8"
EXIM_COMPILE_NUMBER="1"
