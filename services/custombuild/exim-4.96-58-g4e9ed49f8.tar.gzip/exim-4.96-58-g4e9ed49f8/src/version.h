/* automatically generated file - see ../scripts/reversion */
#define EXIM_RELEASE_VERSION "4.96"
#define EXIM_VARIANT_VERSION "58-g4e9ed49f8"
#ifdef EXIM_VARIANT_VERSION
#define EXIM_VERSION_STR EXIM_RELEASE_VERSION "-" EXIM_VARIANT_VERSION
#else
#define EXIM_VERSION_STR EXIM_RELEASE_VERSION
#endif
