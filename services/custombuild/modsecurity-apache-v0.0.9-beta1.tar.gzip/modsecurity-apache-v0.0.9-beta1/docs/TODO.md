#TO-DO

1. Fix Headers I/O
2. Pass Rules and Configurations files 
3. Complete All Phases of Processing 
4. Testing and Debugging 
