## GOLD SPONSORS

* VMWare (Avi Networks)
* F5/NGINX
* Microsoft

## SILVER SPONSORS

* Bug Bounty Switzerland
* Google Cloud Armor
